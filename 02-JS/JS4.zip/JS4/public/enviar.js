//Al llamar a la funcion enviar se redirecciona la pagina web a un enlace enviado, 
// como si fuera un enlace
function enviar(enlace)
{
    window.location.href = enlace;
}