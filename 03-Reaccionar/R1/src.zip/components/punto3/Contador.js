import './contador.css';
import { useState } from 'react';

function Contador(){
    const [numero, setNumero] = useState(0);

    function sumar(){setNumero(numero +1);}
    function restar(){setNumero(numero -1);}

    return(
        <div >
        <h1>{numero}</h1>
        <button onClick={restar} className="Button">disminuir</button>
        <button onClick={sumar} className="Button">aumentar</button>
        </div>
    );

}

export default Contador;