import { parse } from "node:url"

//Funcion para devolver el host de una url
export function obtenerHost(url)
{
    let q = parse(url, true); //esta creara una variable con el parse
    return q.host; //y esta devolvera el host que esta en la url

}

