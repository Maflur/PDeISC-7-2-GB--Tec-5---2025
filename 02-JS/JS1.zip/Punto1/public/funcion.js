let frutas = [];
function formFrutas(event){
    event.preventDefault(); 
    
    //Se crean variables para almacenar los valores
    let f1 = document.getElementById('fruta1').value;
    let f2 = document.getElementById('fruta2').value;
    let f3 = document.getElementById('fruta3').value;

    if(valido) {
        frutas.push(f1); //Se agregan los valores al final del array con push()
        frutas.push(f2);
        frutas.push(f3);
        document.getElementById('frutasText').innerHTML = ''; 
        frutas.forEach(element => {
            document.getElementById('frutasText').innerHTML += element + ', '; 
        });
    }
}

let amigos = []; 
function formAmigos(event){
    event.preventDefault(); 
    
    //Se crean variables para almacenar los valores
    let a1 = document.getElementById('amigo1').value;
    let a2 = document.getElementById('amigo2').value;
    let a3 = document.getElementById('amigo3').value;

    if(valido){
        amigos.push(a1); //Se agregan los valores al final del array con push()
        amigos.push(a2);
        amigos.push(a3);
        document.getElementById('amigosText').innerHTML = '';
        amigos.forEach(element => { 
            document.getElementById('amigosText').innerHTML += element + ', '; 
        });
    }
}

let numeros = []; 
function formNumeros(event){
    event.preventDefault(); //Se previene que reinicie la pagina al dar click en el boton
    
    let num = document.getElementById('numero').value;

    if(parseInt(num) <= numeros[numeros.length-1]) //Se revisa si el numero es mayor al anterior
    {
        document.getElementById('errorText').innerHTML = "El Numero debe ser mayor al anterior";
        valido = false; 
    }
    if(valido) //En caso de que todo este como corresponda
    {
        document.getElementById('errorText').innerHTML = ''; 
        numeros.push(parseInt(num)); 
        document.getElementById('numerosText').innerHTML = ''; 
        numeros.forEach(element => { 
            document.getElementById('numerosText').innerHTML += element + ', '; 
        });
    }
}