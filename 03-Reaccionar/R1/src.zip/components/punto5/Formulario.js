import { useState } from "react";
import './Formulario.css'

function Formulario(){
    const [nombre, setNombre] = useState('');

    function bienvenida(a){
        a.preventDefault();
        let nom = document.getElementById("inputNombre").value;
        setNombre(nom);
        document.getElementById("saludar").style.display ='block';
    }

    return(
        <form onSubmit={bienvenida} className="formulario">
            <label>Nombre: </label>
            <input type="text" id="inputNombre"/>
            <button type="submit" className="submit">Enviar</button>
            <p id="saludar">Hola {nombre} </p>
        </form>);
}

export default Formulario;