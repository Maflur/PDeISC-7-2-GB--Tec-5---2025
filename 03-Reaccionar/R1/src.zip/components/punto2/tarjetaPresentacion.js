import './tarjetaPresentacion.css';

function Tarjeta(props){
    return(
        <table className='tabla'>
            <tr>
                <td className='let'>{props.nombre} {props.apellido}</td>
                <td > <img src={props.foto} className="foto" /></td>
            </tr>
            <tr>
                <td className='let'>{props.profecion}</td>
            </tr>

        </table>
    );
}

export default Tarjeta;

