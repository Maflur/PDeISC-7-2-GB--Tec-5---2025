//importamos el servidor
import {createServer} from 'node:http';
//aca importamos las funciones 
import {writeToFile} from './crear.js';
import {mostrarArchivo} from './leer.js';

//aca de escribe el html con un titulo
writeToFile('prueba.html', `
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Prueba Visual</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: linear-gradient(to bottom, #8e2de2, #4a00e1);
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      color: white;
      font-family: 'Segoe UI', sans-serif;
      text-align: center;
    }
    h1 {
      font-size: 3rem;
      text-shadow: 5px 5px 2px #000000aa;
    }
  </style>
</head>
<body>
  <div>
    <h1>Hola Bienvenido</h1>
  </div>
</body>
</html>
`);


//creamos el servidor
const server = createServer(async (req, res) => {
res.writeHead(200,{'Content-type': 'text/html'});
//aca se espera que el archivo sea leeido 
try{
    const contenido = await mostrarArchivo('prueba.html');
    res.write(contenido.toString());
} catch (error){
    res.write('<h1>error al cargar el archivo</h1>');
}

res.end('');
});

//inicialisamos el servidor
server.listen(3000, '127.0.0.1', () => {
  console.log('Listening on 127.0.0.1:3000');
})