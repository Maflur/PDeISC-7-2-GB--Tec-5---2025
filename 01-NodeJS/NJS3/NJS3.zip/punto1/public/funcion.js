function agregarTex(){document.getElementById('texto').innerHTML = '<p class="parrafo">Hola DOM</p>';}
function cambiarTex(){document.getElementById('texto').innerHTML = '<p class="parrafo">Chau DOM</p>';}
function borrarTex(){document.getElementById('texto').innerHTML = '';}

function agregarImg()
{
    document.getElementById('imagen').innerHTML = '<img id="imag" src="imagenes/hurones.jpg" alt="">';
}

function cambiarImg()
{
    document.getElementById('imagen').innerHTML = '<img id="imag" src="imagenes/patogriton.jpg" alt="">';
}

function tamañoImg()
{
    let w = Math.floor(Math.random() * 500) + 1;
    let h = Math.floor(Math.random() * 500) + 1;
    document.getElementById('imag').style.width = w + 'px';
    document.getElementById('imag').style.height = h + 'px';
}
