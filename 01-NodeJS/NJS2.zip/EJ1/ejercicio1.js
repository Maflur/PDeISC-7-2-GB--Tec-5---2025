import { createServer } from 'node:http';
import { suma, resta, multiplicar, dividir, potencia } from './calculos.js';
import { hora } from './hora.js';
import { numeroAleatorio } from './aleatorio.js';

const server = createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/html' });

  res.write(`
    <html lang="es">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Diario Virtual</title>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
      <style>
        body {
          background-color: #5a189a;
          color: white;
          text-align: center;
          font-family: 'Segoe UI', sans-serif;
        }
        .table {
          background-color: #7b2cbf;
          color: white;
        }
      </style>
    </head>
    <body>
      <div class="container py-5">

        <table class="table table-bordered table-hover">
          <head>
            <tr>
              <th>Suma</th>
              <th>Resta</th>
              <th>Multiplicación</th>
              <th>División</th>
              <th>potencia</th>
            </tr>
          </head>
          <body>
            <tr>
              <td>${suma(5, 4)}</td>
              <td>${resta(7, 4)}</td>
              <td>${multiplicar(3, 5)}</td>
              <td>${dividir(20, 4)}</td>
              <td>${potencia(2,3)}</td>
            </tr>
          </body>
        </table>

        <p class="mt-4">Esta es la hora de Mar del Plata: <strong>${hora()}</strong></p>
        <p>El número aleatorio del 1 al 100 es: <strong>${numeroAleatorio(1, 100)}</strong></p>

        <a href="/" class="btn btn-light mt-4">Recargar página</a>
      </div>
    </body>
    </html>
  `);

  res.end();
});

server.listen(3000, '127.0.0.1', () => {
  console.log('Listening on 127.0.0.1:3000');
});
