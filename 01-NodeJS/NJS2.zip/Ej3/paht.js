import { parse } from "node:url"

//Funcion para devolver el pathname de una url
export function obtenerPath(url)
{
    let q = parse(url, true); //esta creara una variable con el parse
    return q.pathname; //y esta devolvera el pathame de la url
}

