import { useState } from 'react';
import './Tareas.css';
import Tarea from './Funcion';

function Tareas(){
    const [tareas, setTareas] = useState([{
        completa: 'true',
        tarea: 'hacer tarea'},
    {
        completa: 'false',
        tarea: 'correr'},
    {
        completa: 'false',
        tarea: 'tocar el piano'},
    {
        completa: 'true',
        tarea: 'Dormir'},
    ]);

    function agregar(){
        let temp = Array.from(tareas);
        let tar = {
            completa: 'false',
            tarea: 'comer'
        };
        temp.push(tar)
        setTareas(temp);
    }

    return (
        <div className='lista'>
            <button onClick={agregar} className='agregarButton'> Agregar Tarea </button>
            {tareas.map(tar => {
                return (
                    <Tarea 
                        completa = {tar.completa}
                        tarea = {tar.tarea}
                    />
                )
            })}
        </div>
    );
}

export default Tareas;