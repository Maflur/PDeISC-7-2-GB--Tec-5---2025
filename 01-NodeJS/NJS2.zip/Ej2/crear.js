import { writeFile } from 'node:fs/promises'
//se envia el parametro la ruta el contenido para el archivo si el archivo no existe lo va a crear
//si el archivo ya existe lo sobre escribe
export async function writeToFile(fileName, data) 
{
    try {
      //Intentara escribir el archivo o otro caso crearlo si es que no hay
      await writeFile(fileName, data);
    } catch (error) {
      //en caso de no poder lo va a avisar
      console.error(`error: ${error.message}`);
    }
}