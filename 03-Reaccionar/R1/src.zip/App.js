import HolaMundo from './components/punto1/holamundo';
import Tarjeta from './components/punto2/tarjetaPresentacion';
import Contador from './components/punto3/Contador';
import Tareas from './components/punto4/Tareas';
import Formulario from './components/punto5/Formulario';
import './App.css'
import panadero from './components/punto2/panadero.jpg';
function App(){
  return(
    <div>
      <HolaMundo/>
      <br/>
      <Tarjeta 
        nombre = "juang"
        apellido ="perez"
        foto={panadero}
        profecion ="panadero"
      />
       <br/>
      <Contador></Contador>
      <br/>
      <Tareas></Tareas>
      <br/>
      <Formulario></Formulario>

    </div>
  );

}

export default App;