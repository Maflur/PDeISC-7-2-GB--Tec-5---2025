//esta funcion devuelve el valor de la suma de dos numeros
export function suma(n1 ,n2){
    return n1+n2;
}
//esta funcion devuelve el valor de la resta de dos numeros
export function resta(n1,n2){
    return n1-n2;
}
//esta funcion devuelve el valor de la multiplicacion de dos numeros
export function multiplicar(n1,n2){
    return n1*n2;
}
//esta funcion devuelve el valor de una divicion de dos numeros
export function dividir(n1,n2){
    return n1/n2;
}
//Una funcion que devuelve el valor exponenciando a otro numero
export function potencia(num, exp)
{
    let result = 1;
    for(let i=0; i<exp; i++)
    {
        result = result*num;
    }
    return result;
}