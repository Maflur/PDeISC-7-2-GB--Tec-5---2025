import { useState } from 'react';

function Tarea(props) {
    const [completa, setCompleta] = useState(props.completa);

    function cambiarEstado() {
        setCompleta(completa === 'true' ? 'false' : 'true');
    }

    return (
        <div className="tarea" >
            <input 
                type="checkbox" 
                checked={completa === 'true'} 
                onChange={cambiarEstado} 
            />
            <span>{props.tarea}</span>
        </div>
    );
}

export default Tarea;
