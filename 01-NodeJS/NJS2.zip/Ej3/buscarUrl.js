import { parse } from "node:url"

//Funcion para devolver la busqueda de una url
export function obtenerSearch(url)
{
    let q = parse(url, true); //esta creara una bariable con el parse
    return q.search; //y esta devolvera la busqueda que esta en la url
}


